        </section>
    </section>
    <footer>
        <p>&copy; 2022 - IRGA RAMADHAN PUTRA - 312010067</p>
    </footer>
    </div>
</body>
</html>