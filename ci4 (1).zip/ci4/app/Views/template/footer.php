        </section>
    </section>
    <footer>
        <p>&copy; 20222 - IRGA RAMADHAN PUTRA - 312010067 </p>
    </footer>
    </div>
</body>
</html>